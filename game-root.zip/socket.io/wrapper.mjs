import io from "./dist/index.js";

export const {Server, Namespace, Socket} = io;
